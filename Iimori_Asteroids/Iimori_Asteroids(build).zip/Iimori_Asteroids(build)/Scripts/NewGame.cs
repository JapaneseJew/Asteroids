﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
/// <summary>
/// https://www.youtube.com/watch?v=MeWjyLpsYw8&feature=youtu.be
/// </summary>
public class NewGame : MonoBehaviour {

	// Use this for initialization
	void Start () {
        SceneManager.LoadScene("SampleScene"); //load samplescene
    }
	
	// Update is called once per frame
	void Update () {

    }
}
